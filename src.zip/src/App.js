import React from "react";
import  '@fortawesome/react-fontawesome'
import './App.css';
import ChatBody from "./Component/ChatBody/ChatBody";
function App() {
  return (
   
    <div className="__main">
      <ChatBody />
    </div>
  );
}
 

export default App;
