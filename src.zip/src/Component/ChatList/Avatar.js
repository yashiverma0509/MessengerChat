/******************************************************************************
 * Copyright © 2021 HARMAN International.
 * All rights reserved.
 *
 * Author: Yashi Verma
 * Created: 08.05.2023
 *****************************************************************************/
import React, { Component } from "react";

export default class Avatar extends Component {
 
  render() {
    return (
      <div className="avatar">
        <div className="avatar-img">
          <img src={this.props.image} alt="#" />
        </div>
        <span className={`isOnline ${this.props.isOnline}`}></span>
      </div>
    );
  }
}