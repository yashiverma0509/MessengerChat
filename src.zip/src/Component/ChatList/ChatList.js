import React, { Component } from "react";
import { FaPencilAlt, FaSearch } from "react-icons/fa";
import "./chatList.css";
import ChatListItems from './ChatListItems';
import Avatar from "../ChatList/Avatar";
export default class ChatList extends Component {
  allChatUsers = [
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1001.jpeg",
      id: 1,
      name: "Leanne Graham",
      active: true,
      isOnline: true,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1002.jpeg",
      id: 2,
      name: " Ervin Howell",
      active: false,
      isOnline: false,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1003.jpeg",
      id: 3,
      name: "Clementine Bauch",
      active: false,
      isOnline: false,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1004.jpeg",
      id: 4,
      name: "Patricia Lebsack",
      active: false,
      isOnline: true,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1005.jpeg",
      id: 5,
      name: "Chelsey Dietrich",
      active: false,
      isOnline: false,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1006.jpeg",
      id: 6,
      name: "Mrs. Dennis Schulist",
      active: false,
      isOnline: true,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1007.jpeg",
      id: 7,
      name: "Kurtis Weissnat",
      active: false,
      isOnline: true,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1008.jpeg",
      id: 8,
      name: "Nicholas Runolfsdottir V",
      active: false,
      isOnline: false,
    },
    {
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1009.jpeg",
      id: 9,
      name: "Glenna Reichert",
      active: false,
      isOnline: true,
    },
    {
      image: "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1010.jpeg",
      id: 10,
      name: "Clementina DuBuque",
      active: false,
      isOnline: true,
    },
  ];
  constructor(props) {
    super(props);
    this.state = {
      allChats: this.allChatUsers,
    };
  }
  render() {
    return (
      <div className="main__chatlist">
        <div className="blocks">
            <div className="current-chatting-user">
              <Avatar
                isOnline="active"
                image="https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1008.jpeg"
              />
              <div>
              
          <h3>Nicholas Runolfsdottir V</h3>
         
          
        </div>
       
             
            
            </div>
          </div>
       
        <div className="chatList__search">
          <div className="search_wrap">
            <input type="text" placeholder="Search Here" required />
            <FaSearch/>
            {/* <button className="search-btn">
              <i className="fa fa-search"></i>
            </button> */}
          </div>
        </div>
        <div className="chatlist__items">
          {this.state.allChats.map((item, index) => {
            return (
              <ChatListItems
                name={item.name}
                key={item.id}
                animationDelay={index + 1}
                active={item.active ? "active" : ""}
                isOnline={item.isOnline ? "active" : ""}
                image={item.image}
              />
            );
          })}
        </div>
      </div>
    );
  }
}