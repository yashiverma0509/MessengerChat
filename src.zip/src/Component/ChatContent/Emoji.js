// import data from "@emoji-mart/data";
// import Picker from "@emoji-mart/react";
// import React, { useState } from 'react'
// const Chat = {{remoteAvatar}} => {
 
//     const [showEmojis ,setShowEmojis] =useState();
//     const [message ,setMessage] =useState("");
//     const [cursorPosition ,setCursorPosition] =useState();
//     const inputRef =createRef();

// };

// const pickEmoji =(e ,{ emoji}) =>{
//     const ref = inputRef.current;
//     ref.Focus();
//     const start= message.substring(0, ref.selectionStart);
//     const end = message. substring(ref.selectionStart);
//     const text = start+emoji+end;
//     setMessage(text);
//     setCursorPosition(start.length+emoji.length)
// };


// const handleShowEmojis =()=>{
//     inputRef.current.Focus();
//     setShowEmojis(!showEmojis);
// };