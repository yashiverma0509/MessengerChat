


import React, { Component,  createRef, useState,  } from "react";

import './chatContent.css';
import Avatar from "../ChatList/Avatar";
import ChatItem from './ChatItem';
import {   FaMicrophone, } from "react-icons/fa";
import {AiOutlineSend ,AiOutlinePaperClip, AiOutlineCamera,AiOutlineHeart,AiOutlineSearch} from "react-icons/ai"
import { BsBell, BsEmojiSmile } from "react-icons/bs";

export default class ChatContent extends Component {
  // const handleShowEmojis{
  //   inputRef.current.focus();
  //   setShowEmojis(!showEmojis);
  // };
  messagesEndRef = createRef(null);
 
  
  chatItms = [
    {
      key: 1,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1007.jpeg",
      type: "",
      msg: "Hiiiii",
    },
    {
      key: 2,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1008.jpeg",
      type: "other",
      msg: "I am fine.",
    },
    {
      key: 3,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1008.jpeg",
      type: "other",
      msg: "What about you?",
    },
    {
      key: 4,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1007.jpeg",
      type: "",
      msg: "Awesome these days.",
    },
    {
      key: 5,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1008.jpeg",
      type: "other",
      msg: "Finally. We Connect",
    },
    {
      key: 6,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1007.jpeg",
      type: "",
      msg: "how are you ?",
    },
    {
      key: 7,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1008.jpeg",
      type: "other",
      msg: "I am planning a trip, would be join?",
    },
    {
      key: 8,
      image:
        "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1007.jpeg",
      type: "",
      msg:" yeah ofcourse"
    },
  ];

  constructor(props) {
    super(props);
    this.state = {
      chat: this.chatItms,
      msg: "",
    };
  }

  scrollToBottom = () => {
    this.messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
  };

  componentDidMount() {
    window.addEventListener("keydown", (e) => {
      if (e.keyCode === 13) {
        if (this.state.msg !== "") {
          this.chatItms.push({
            key: 1,
            type: "",
            msg: this.state.msg,
            image:
              "https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1007.jpeg",
          });
          this.setState({ chat: [...this.chatItms] });
          this.scrollToBottom();
          this.setState({ msg: "" });
        }
      }
  });
    this.scrollToBottom();
  }
  onStateChange = (e) => {
    this.setState({ msg: e.target.value });
     e.preventDefault();
  };
//  function sendMessage(){
//   const[msg,setMsg] = useState('')
  

  render() {
    return (
      <div className="main__chatcontent">
        <div className="content__header">
          <div className="blocks">
            <div className="current-chatting-user">
              <Avatar
                isOnline="active"
                image="https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1007.jpeg"
              />
              <p>Kurtis Weissnat</p>
            </div>
          </div>

          <div className="blocks">
            <div className="settings">
            <button className="btn-nobg">
                <i><AiOutlineSearch/></i>
              </button>
              <button className="btn-nobg">
                <i><AiOutlineHeart/></i>
              </button>
              
              <button className="btn-nobg">
                <i><BsBell/></i>
              </button>
            </div>
          </div>
        </div>
        <div className="content__body">
          <div className="chat__items">
            {this.state.chat.map((itm, index) => {
              return (
                <ChatItem
                  animationDelay={index + 2}
                  key={itm.key}
                  user={itm.type ? itm.type : "me"}
                  msg={itm.msg}
                  image={itm.image}
                />
              );
            })}
            <div ref={this.messagesEndRef} />
          </div>
        </div>
        <div className="content__footer">
          <div className="sendNewMessage">
            <button className="addFiles">
              <i ><FaMicrophone/></i>
            </button>
            {/* <form onSubmit={this.sendMessage}> */}
            <input 
              type="text"
              placeholder="Write Something"
              onChange={this.onStateChange}
              value={this.state.msg}
             
            />
            
             {/* <button className="addFiles" >
              <i><AiOutlinePaperClip/></i>
            </button>
            onChange{(e) =>setMsg(e.target.value)}
            <button className="addFiles" >
            this.sendMessage
              <i><AiOutlineCamera/></i>
            </button> */}
            <button className="addFiles" >
            <BsEmojiSmile />
            </button> 
           
            <button className="send" onSubmit={this.onStateChange} >
              <i><AiOutlineSend/></i>
            </button>
            {/* </form> */}
          </div>
        </div>
      </div>
    );
  }
}