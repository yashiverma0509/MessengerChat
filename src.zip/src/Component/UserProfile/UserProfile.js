

import React, { Component } from "react";
import "./userProfile.css";

import { BsCameraVideoFill, BsFillChatFill,BsFillPersonFill,BsFillHeartFill } from "react-icons/bs";

export default class UserProfile extends Component {
  toggleInfo = (e) => {
    e.target.parentNode.classList.toggle("open");
  };
  render() {
    return (
      <div className="main__userprofile">
        <div className="profile__card user__profile__image">
          <div className="profile__image">
            <img src="https://panorbit.in/wp-content/uploads/2019/hotlink-ok/1008.jpeg"/>
          </div>
          <h3>Nicholas Runolfsdottir V</h3>
          <h5> Maxime_Nienow,
          "Sherwood@rosamond.me"
          ph-no.: 586.493.6943 x140
          website": "jacynthe.com"</h5>         
          
            <div className="outbtn">
           <button>sign out</button> 
           </div>
        </div>
        
       
      </div>
    );
  }
}