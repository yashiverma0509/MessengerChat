/******************************************************************************
 * Copyright © 2021 HARMAN International.
 * All rights reserved.
 *
 * Author: Yashi Verma
 * Created: 08.05.2023
 *****************************************************************************/

import React, { Component } from "react";
import "./chatBody.css";
import ChatList from "../ChatList/ChatList";
import ChatContent from "../ChatContent/ChatContent";
import UserProfile from "../UserProfile/UserProfile";
// import { Emoji } from "emoji-picker-react";

export default class ChatBody extends Component {
  render() {
    return (
      <div className="main__chatbody">
        <ChatList/>
        <ChatContent />
        <UserProfile />
       
      </div>
    );
  };
};